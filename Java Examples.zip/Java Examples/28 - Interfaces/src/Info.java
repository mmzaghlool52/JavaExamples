public interface Info {
    public void showInfo();
}